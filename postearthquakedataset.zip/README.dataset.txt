# Post Earthquake Interior Environment > Modified and Augmentations
https://universe.roboflow.com/rmit-oeng1090-master-research-thesis/post-earthquake-interior-environment

Provided by a Roboflow user
License: CC BY 4.0

